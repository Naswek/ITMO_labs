#include "main.h"
#include "tm1637.h"

volatile uint32_t tickCount;
uint32_t last_display_update;
uint16_t counter;
char lastKey;
uint32_t lastScanTime;


void osSystickHandler(void) {
  tickCount++;
}


void initGPIO() {
  // Включаем тактирование GPIOA и GPIOB
  RCC->AHBENR |= RCC_AHBENR_GPIOAEN | RCC_AHBENR_GPIOBEN;

  // Настраиваем PA5 как выход
  GPIOA->MODER = (GPIOA->MODER & ~(3 << 10)) | (1 << 10);
  GPIOA->OTYPER &= ~(1 << 5);
  GPIOA->OSPEEDR |= (1 << 10);
}

void initUSART2() {
  // Включаем тактирование USART2
  RCC->APB1ENR |= RCC_APB1ENR_USART2EN;

  // Настраиваем PA2 и PA3 в альтернативный режим
  GPIOA->MODER = (GPIOA->MODER & ~(0xF << 4)) | (0xA << 4);
  GPIOA->AFR[0] = (GPIOA->AFR[0] & ~(0xFF << 8)) | (1 << 8) | (1 << 12);

  // Настраиваем USART2
  USART2->BRR = 417; // 48MHz/115200
  USART2->CR1 = USART_CR1_TE | USART_CR1_UE;
}

void initSysTick() {
  SysTick->LOAD = 47999; // 1ms при 48MHz
  SysTick->VAL = 0;
  SysTick->CTRL = (1 << 2) | (1 << 1) | (1 << 0);
}

int _write(int file, uint8_t *ptr, int len) {
  for (int i = 0; i < len; i++) {
    while (!(USART2->ISR & USART_ISR_TXE));
    USART2->TDR = ptr[i];
  }
  return len;
}

void checkTickCount() {
  if ((tickCount % 2000) == 0) {
    GPIOA->ODR ^= (1 << 5); // Toggle LED
    printf("tickCount = %d!\n", tickCount++);
  }
}

int execute(int first, int second, char operation) {
  switch (operation) {
    case '+':
      return first + second;
    case '-':
      return first - second;
    case '*':
      return first*second;
    case '/':
      if (second == 0) {
        printf("Division by zero\n");
        return 0;
      }
      return first / second;
    default:
      printf("Unknown operation\n");
      return 0;
  }
}

int main(void) {
  initGPIO();
  initUSART2();
  initSysTick();
  initKeyboard();
  tm1637_init();

  printf("Hello, %s!\n", "Wokwi Simulation");

  GPIOA->ODR |= (1 << 5); // Включаем LED

int first = -1;
int second = -1;
char operation = '\0';
char lastKey = '\0';
int operationCounter = 0;

while (1) {
    checkTickCount();

    char key = scanKeyboard();

    if (key == '\0') {
        continue;
    }

    if (first == -1) {
        if (key >= '0' && key <= '9') {
            first = key - '0';
            printf("First number: %d\n", first);
            tm1637_display_number(first);
        }
        continue;
    }

    if (second == -1 && key == '*') {
        operationCounter++;

        if (operationCounter > 4) {
            operationCounter = 1;
        }

        switch (operationCounter) {
            case 1:
                operation = '+';
                break;
            case 2:
                operation = '-';
                break;
            case 3:
                operation = '*';
                break;
            case 4:
                operation = '/';
                break;
        }

        printf("Selected operation: %c\n", operation);
        continue;
    }

    if (second == -1 && operation != '\0') {
        if (key >= '0' && key <= '9') {
            second = key - '0';
            printf("Second number: %d\n", second);
            tm1637_display_number(second);
        }
        continue;
    }

    if (key == '#') {
        int result = execute(first, second, operation);
        printf("%d %c %d = %d\n",
               first, operation, second, result);
        tm1637_display_number(result);
        first = -1;
        second = -1;
        operation = '\0';
        operationCounter = 0;
        continue;
    }
}
  return 0;
}